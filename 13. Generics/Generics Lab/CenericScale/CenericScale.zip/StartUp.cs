﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericScale
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}

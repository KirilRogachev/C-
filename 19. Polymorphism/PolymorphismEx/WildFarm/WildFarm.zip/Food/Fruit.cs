﻿namespace WildFarm.Food
{
   public class Fruit:FoodCs
    {
        public Fruit(int quantity)
            : base(quantity)
        {
        }
    }
}

﻿namespace WildFarm.Food
{
   public class Meat:FoodCs
    {
        public Meat(int quantity)
             : base(quantity)
        {
        }
    }
}

﻿namespace WildFarm.Food
{
   public class Seeds:FoodCs
    {
        public Seeds(int quantity)
             : base(quantity)
        {
        }
    }
}

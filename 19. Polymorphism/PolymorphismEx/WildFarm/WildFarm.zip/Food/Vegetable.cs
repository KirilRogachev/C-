﻿namespace WildFarm.Food
{
    public class Vegetable : FoodCs
    {
        public Vegetable(int quantity)
            : base(quantity)
        {
        }
    }
}


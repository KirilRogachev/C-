﻿namespace Food
{
   public interface IFormat
    {
        string Name { get; }
        int Food { get; }
    }
}

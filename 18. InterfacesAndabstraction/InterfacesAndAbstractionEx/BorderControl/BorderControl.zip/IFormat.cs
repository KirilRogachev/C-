﻿namespace BorderControl
{
    interface Format
    {
        string Model { get; }
        string Name { get; }
        int Age { get; }
        
        string Id { get; }
    }
}

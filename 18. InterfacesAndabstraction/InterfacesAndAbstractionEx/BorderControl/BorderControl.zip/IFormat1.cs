﻿namespace BorderControl
{
    internal interface IFormat
    {
    }
}
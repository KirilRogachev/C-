﻿namespace BirhtdayCelebrations
{
   public interface IFormat
    {
        string Kind { get; }
        string Date { get; }
    }
}

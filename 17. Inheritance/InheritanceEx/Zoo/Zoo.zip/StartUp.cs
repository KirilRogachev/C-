﻿namespace Zoo
{
    using System;

    public class StartUp
    {
       public static void Main()
        {
            Lizard liz = new Lizard("Kiro");
            Console.WriteLine(liz.Name);
          
        }
    }
}

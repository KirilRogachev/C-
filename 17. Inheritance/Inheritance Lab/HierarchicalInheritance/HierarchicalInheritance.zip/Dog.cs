﻿namespace Farm
{
   public class Dog:Animal
    {
        public string Bark()
        {
            return "barking...";
        }
    }
}

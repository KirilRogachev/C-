﻿namespace Farm
{
    public class Cat:Animal
    {
        public string Meow()
        {
            return "meowing...";
        }
    }
}

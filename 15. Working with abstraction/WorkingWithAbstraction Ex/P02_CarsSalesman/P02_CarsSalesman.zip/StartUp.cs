﻿namespace P02_CarsSalesman
{
    public class CarSalesman
    {
        static void Main(string[] args)
        {
            Runner run = new Runner();
            {
                run.Run();
            }

        }
    }

}

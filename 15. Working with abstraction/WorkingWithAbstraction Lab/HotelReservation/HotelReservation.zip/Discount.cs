﻿namespace HotelReservation
{
    public enum Discount
    {
        none,
        VIP=20,
        SecondVisit=10

    }
}

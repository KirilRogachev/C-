﻿namespace PointInRectangle
{
    public class Point
    {
        public Point(int X, int Y)
        {
            this.x = X;
            this.y = Y;
        }
        public int x { get; private set; }
        public int y { get; private set; }
    }
}
